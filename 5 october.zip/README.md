This is the repository of Live Trainings conducted for September 25 Batch - Python for Data Science
