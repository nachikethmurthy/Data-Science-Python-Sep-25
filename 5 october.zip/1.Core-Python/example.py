hello = 100
data = 500

def hello_world():
    return "Welcome to class"